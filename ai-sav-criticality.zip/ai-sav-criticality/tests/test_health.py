
        
from fastapi.testclient import TestClient
from app.main import app, classifier


def fake_load():
    classifier._loaded = True


def fake_classify(commentaire: str, ticket_number=None, use_distlbert=True):
    return {
        "ticket_number": ticket_number,
        "label": "CRITIQUE",
        "label_value": 1,
        "confiance": 92.5,
        "is_critique": True,
        "sentiment": "NEGATIF",
        "sentiment_score": -0.62,
        "urgence": 3,
        "emotion": "PEUR/ALERTE",
        "signaux": ["mots_critiques:2", "urgence:1"],
        "modele_utilise": "CamemBERT",
        "model_version": "v1",
    }


def test_predict():
    # Sauvegarde les vraies méthodes
    original_load = classifier.load
    original_classify = classifier.classify

    # Mock
    classifier.load = fake_load
    classifier.classify = fake_classify

    payload = {
        "commentaire": "Je viens de constater un prélèvement non autorisé de 540€.",
        "ticket_number": "TEST-PRED-001",
        "use_distlbert": True,
    }

    try:
        with TestClient(app) as client:
            response = client.post("/api/v1/classify", json=payload)

        assert response.status_code == 200

        data = response.json()
        assert data["ticket_number"] == "TEST-PRED-001"
        assert data["label"] == "CRITIQUE"
        assert data["label_value"] == 1
        assert data["is_critique"] is True
        assert data["confiance"] == 92.5
        assert data["urgence"] == 3
        assert data["emotion"] == "PEUR/ALERTE"
        assert data["modele_utilise"] == "CamemBERT"
        assert data["model_version"] == "v1"
    finally:
        classifier.load = original_load
        classifier.classify = original_classify