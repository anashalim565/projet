from fastapi import Header, HTTPException, status
from app.config import settings


def verify_internal_api_key(x_internal_api_key: str | None = Header(default=None)):
    if x_internal_api_key != settings.internal_api_key:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Internal access only"
        )